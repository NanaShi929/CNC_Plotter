# 3D Printing Instructions & Parts Guide

This directory contains all the STL files required to build the mechanical frame of the CNC Plotter. 

## ⚙️ General Printing Guidelines

*   **Print Settings:** All files can be printed using **Normal settings** 
*   **Rod Sizing Note:** These 3D models are specifically designed to fit **10mm linear smooth rods**. If you are building your plotter with a different rod size (such as 8mm), you will need to design and print custom fillers/adapter sleeves to ensure the rods and bearings fit snugly without wobbling.

---

## 📂 File Structure & Print Quantities

Below is the directory structure along with the exact number of times each part needs to be printed.

### `Limit Switch` Folder
*   **Print Quantity:** 4x
*   *Used for mounting the X-, X+, Y-, and Y+ endstops.*

### `Pen_Holder` Folder
*   **Print Quantity:** 1x
*   *Contains the carriage and servo mounting mechanism.*

### `X-axis` Folder
You need to print both files in this folder twice.
*   `nema_holder.stl` - **Print Quantity:** 2x
*   `x-axis_holder.stl` - **Print Quantity:** 2x

### `Y-axis` Folder
This folder contains three sub-folders:
*   `EndCap` / - **Print Quantity:** 2x
*   `Nema-Holder` / - **Print Quantity:** 1x
*   `One-endpoint` / - **Print Quantity:** 1x